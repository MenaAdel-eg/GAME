package game.engine.monsters;

import game.engine.Role;

public class MultiTasker extends Monster {
	private int normalSpeedTurns;
	
	public MultiTasker(String name, String description, Role role, int energy) {
		super(name, description, role, energy);
		this.normalSpeedTurns = 0;
	}

	public int getNormalSpeedTurns() {
		return normalSpeedTurns;
	}

	public void setNormalSpeedTurns(int normalSpeedTurns) {
		this.normalSpeedTurns = normalSpeedTurns;
	}
	
	//-------------------------------------------------
	
	  public void executePowerupEffect(Monster opponentMonster) {
	        this.normalSpeedTurns = 2;
	    }

	  public void move(int distance) {
	        if (this.normalSpeedTurns > 0) {
	            this.normalSpeedTurns--;
	            super.move(distance); //ba3d el powerup effect
	        } else {
	            super.move(distance / 2); //normal halved distance (dah el 3ady)
	        }
	    }
	  
}
