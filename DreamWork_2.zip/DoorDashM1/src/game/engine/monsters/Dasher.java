package game.engine.monsters;

import game.engine.Role;

public class Dasher extends Monster {
	private int momentumTurns;

	public Dasher(String name, String description, Role role, int energy) {
		super(name, description, role, energy);
		this.momentumTurns = 0;
	}
	
	public int getMomentumTurns() {
		return momentumTurns;
	}
	
	public void setMomentumTurns(int momentumTurns) {
		this.momentumTurns = momentumTurns;
	}
	
	//-----------------------------------------------
	
	 public void executePowerupEffect(Monster opponentMonster) {
	        this.momentumTurns = 3;
	 }
	 
	 public void move(int distance) {
	        int actualDistance = distance * 2; //move at normal speed
	        if (this.momentumTurns > 0) {
	            actualDistance = distance * 3; //active power up effect
	            this.momentumTurns--;
	        }
	        super.move(actualDistance);
	    }

}