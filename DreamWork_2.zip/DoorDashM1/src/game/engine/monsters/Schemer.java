package game.engine.monsters;
import game.engine.Role;
import game.engine.Board;

public class Schemer extends Monster {
	
	public Schemer(String name, String description, Role role, int energy) {
		super(name, description, role, energy);
	}
	
	//--------------------------------------------
	
	private int stealEnergyFrom(Monster target) {
        int amount = game.engine.Constants.SCHEMER_STEAL;
        if (target.getEnergy() < amount) {
            amount = target.getEnergy();
        }
        target.alterEnergy(-amount);
        return amount;
    }
	
	public void executePowerupEffect(Monster opponentMonster) {
        int totalStolen = 0;
        totalStolen += stealEnergyFrom(opponentMonster);
        
        for (int i = 0; i < Board.getStationedMonsters().size(); i++) {
            Monster m = Board.getStationedMonsters().get(i);
            totalStolen += stealEnergyFrom(m);
        }
        
        this.alterEnergy(totalStolen);
    }
}
